/*
 *Anil Dhungel 
 *CSIS-1410
 *Assignment Interface
 */

package interfacePackage;

public interface Printable
{
   void print();
}
