
package interfacePackage;

public interface Shape 
{
	 double perimeter(); 
	 double area();
}
